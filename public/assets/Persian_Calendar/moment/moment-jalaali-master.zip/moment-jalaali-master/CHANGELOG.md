## 0.7.3

* Fix locale fa loading based on moment documentation (#134)

## 0.7.2

* Fix when formatting using LTS local formatting token (#106)

## 0.7.1

* Support modern persian via dialect option, see [here](https://github.com/jalaali/moment-jalaali/issues/101)

## 0.7.0

* Support persian digits. Disabled by default.
* Drop support for component
* Drop support for bower
* Simplify build process
